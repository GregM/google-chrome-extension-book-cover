google-chrome-extension-benjamin-buckingham
==========================================

When opening a new tab in Google Chrome, this Google Chrome Extension will display the cover

Available here: https://chrome.google.com/webstore/detail/fashionable-new-tab-page/popjcdnkbagcglelodcijahlebackbfc?hl=en&gl=US

Code is MIT License.

Cover image is not available for open-source, sorry. Copyright 2014 Gregory Mazurek.
